
package Lab8;
import java.util.Scanner;
public class q2 
{
	Node head;
	static class Node
	{
		char data;
		Node next;
		Node prev;
		Node(char d)
		{
			this.data = d;
			next = null;
			prev = null;
		}
	}
	public q2 insert(q2 list, char data)
	{
		Node new_node = new Node(data);
		
		if(list.head==null)
		{
			list.head = new_node;
			new_node.prev=null;
			
		}
		else
		{
			Node n = list.head;
			while(n.next!=null)
			{
				n = n.next;
				
			}
			n.next = new_node;
			new_node.prev = n;
		}
		
		return list;
		
	}
	
	public void show(q2 list)
	{
		Node n = list.head;
		while(n.next!=null)
		{
			System.out.print(n.data);
			n = n.next;
		}System.out.print(n.data);
		
	}
	public q2 insertatpos(q2 list, int n, char d)
	{
		Node node = new Node(d);
		Node point=list.head;
		int i=0;
		while(point.next!=null && i!=n )
		{
			
			point = point.next;
			i++;
		}
		Node curr = point.next;
		point.next = node;
		node.next = curr;
		return list;
			
	}
	
	public q2 del(q2 list, int n)
	{
		Node point=list.head;
		int i=0;
		while(point.next!=null && i!=n)
		{
			point = point.next;
			i++;
		}
		point.next = point.next.next;
		return list;
	}

	public static void main(String[] args) {
		q2 list = new q2();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the text");
		String s = sc.next();
	
		for(int i=0;i<s.length(); i++)
		{
			list.insert(list, s.charAt(i));
			
			
		}
		
		int i = s.length();
		System.out.println("Now cursor is at the last position");
		int flag =1;
		while(flag==1)
		{
			System.out.println("Press 0 to move left and 1 to move right");
			System.out.println("Press 2 to insert the character after the cursor");
			System.out.println("Press 4 to delete");
			System.out.println("Press 5 to print");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 0:
			{
				i--;
				break;
			}
			case 1:
			{
				i++;
				break;
				
			}
			
			case 2:
				System.out.println("Enter the character");
				String d = sc.next();
				list.insertatpos(list, i-1, d.charAt(0));
				break;
			case 4:
				if(i==s.length()-1)
				{
					break;
				}
				else
				{
					if(i>=s.length())
					{
						System.out.println("Can't delete");
						break;
					}
					else
					{
						list.del(list,i);
					}	break;
				}
			case 5:
				list.show(list);
				break;			
			
			}
		
			System.out.println("Press 1 to continue else press 0 to exit ");
			flag = sc.nextInt();		
		
		}

	}
}
