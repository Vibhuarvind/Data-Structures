
package Lab8;
import java.util.Scanner;
public class q1 
{

	Node head;
	static class Node
	{
		int data;
		Node next;
		Node prev;
		Node(int d)
		{
			prev = null;
			next = null;
			data = d;
		}
	}
	public static q1 insert(q1 list, int d)
	{
		Node node = new Node(d);
		node.data = d;
		
		if(list.head== null)
		{
			list.head=node;
			node.prev=null;
		}
		else
		{
			Node n = list.head;
			while(n.next!=null)
			{
				n = n.next;
				
			}
			n.next = node;
			node.prev=n;
			
		}
		sort(list);
		return list;
	}
	public static q1 delNode(q1 list, Node d)
	{
		if (list.head == null || d == null) 
            return null; 
  
     
        if (list.head == d) 
            list.head = d.next; 
  
      
        if (d.next != null) 
            d.next.prev = d.prev; 
  
       
        if (d.prev != null) 
        {
            d.prev.next = d.next; 
        }
   
        sort(list);
        return list; 
		 
	}
	public static q1 delnodeatpos(q1 list, int n)
	{
		if(list.head==null || n<=0)
		{
			return list;
		}
		Node curr = list.head;
		int i;
		for(i=1; curr!=null&&i<n; i++)
		{
			curr = curr.next;
		}
		if(curr==null)
		{
			return list;
			
		}
		delNode(list, curr);
		sort(list);
		return list;
	}
	
	public static void print(q1 list)
	{
		Node last = list.head;
		while(last!=null)
		{
			System.out.println(last.prev + " " + last.data + " " + last + " " + last.next);
			last = last.next;
		}
	}
	public static void sort(q1 list)
	{
		Node curr = null, ind = null;
		int temp;
		if(list.head == null)
		{
			return ;
			
		}
		else
		{
			for(curr = list.head; curr.next!=null ; curr = curr.next)
			{
				for(ind = curr; ind.next!=null; ind= ind.next)
				{
					if(curr.data>ind.data)
					{
						temp = curr.data;
						curr.data = ind.data;
						ind.data = temp;
					}
					
				}
				if(curr.data>ind.data)
				{
					temp = curr.data;
					curr.data = ind.data;
					ind.data = temp;
				}
				
				
			}
			
			
			
		}
	}
	public static void main(String[] args) {
		q1 obj = new q1();
		int flag = 1;
		Scanner sc = new Scanner(System.in);
		while(flag==1)
		{
			System.out.println("Enter 1 for insertion");
			System.out.println("Enter 2 for deletion");
			System.out.println("Enter 3 for printing the address");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1: 
				System.out.println("How many numbers you want to enter");
				int n = sc.nextInt();
				if(n==0)
				{
					break;
				}
				while(n>0)
				{
					System.out.println("Enter the number to be inserted");
					int num = sc.nextInt();
					insert(obj, num);
					n--;					
				}
				break;
			case 2:
				System.out.println("Enter the number to be deleted");
				int num = sc.nextInt();
				delnodeatpos(obj,num);
				break;
			case 3:
				print(obj);
			}
			System.out.println("Press 1 to continue and 0 to exit! ");
			flag = sc.nextInt();
			if(flag ==0)
			{
				System.out.println("You are outside now!");
			}
					
		}
		
		

	}
}
