package dslab3;
import java.util.Scanner;
public class Q2 {
	static void sorting(int[][] arr) {
		for(int i=0;i<arr.length;i++)
		{
			for(int u=0;u<arr.length;u++)
			{
				for(int j=u;j<arr[i].length;j++)
				{
					if(arr[i][u]>arr[i][j]) {
						int temp=arr[i][u];
						arr[i][u]=arr[i][j];
						arr[i][j]=temp;
						
					}
				}
			}
		}
		//horizontal sorting (basically swapping adjacent elements)
		//bubble sorting
		
		
		for(int x=0; x<arr[0].length; x++)
		{
			for(int y=0; y<arr.length; y++)
			{
				for(int z=0; z<arr.length-x-1; z++)
				{
					if(arr[z][y]>arr[z+1][y])
					{
						int temp2 = arr[z][y];
						arr[z][y] = arr[z+1][y];
						arr[z+1][y] = temp2;
					}
				}
			}
		}
		//vertical sorting of  array elements.
			
		
		System.out.println("here's ur sorted array : ");
		//displaying sorted array.
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		
	}	
	
	public static void main(String args[]) {
		int[][] arr = {
			      {23, 19, 1, 5}, 
			      {11, 16, 25, 38}, 
			      {54, 49, 45, 57},
			      {52, 51, 66, 59}
			      
			};
		
		//calling function for sorted array.
		sorting(arr);
		
		Scanner sc=new Scanner(System.in);
		//searching element from 2d array
		System.out.println("enter the element u wanna search= ");
		int e=sc.nextInt();
		int flag=0;
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				if(arr[i][j]==e) 
				{
					flag=1;
				}
			}
		}
		if(flag==1){
			System.out.println("element is present in the given 2d array . ");
		}
		if(flag==0) 
		{
			System.out.println("element not found !!!!!! ");
		}		
	}

}
