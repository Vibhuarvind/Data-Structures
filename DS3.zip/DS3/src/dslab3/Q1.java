package dslab3;
import java.util.Scanner;
public class Q1 {
	 static Scanner sc = new Scanner(System.in);
	int arr[]= new int[5]; //top5
	String name;
	int total;
	static Q1 obj[] = new Q1[10];
	
	//method to calculate the run score of the player.
	static int total(int[] arr) {
		 int sum=0;
		 for(int i=0;i<arr.length;i++) {
			if(i==0) {
				sum=sum+1*arr[0];
			}
			else if(i==1) {
				sum=sum+2*arr[1];
			}
			else if(i==2) {
				sum=sum+4*arr[2];
			}
			else if(i==3) {
				sum=sum+6*arr[3];
			}
			
			else if(i==4) {
				sum=sum+8*arr[4];
			}
		 }
		 
		 return sum;
	 }
	
	//method to take input from user
	 static void input(int n) {
		 for(int i=0;i<7;i++) 
		 {
			 obj[i]=new Q1();
		}
		 for(int j=0;j<n;j++) {
			     System.out.println("Enter the name of the player");
			     obj[j].name=sc.next();
			     int arr1[]= new int[5]; //arr1 for selecting top5
			     System.out.println("Enter the number of 1s = ");
				 arr1[0]=sc.nextInt();
				 System.out.println("Enter the number of 2s = ");
				 arr1[1]=sc.nextInt();
				 System.out.println("Enter the number of 3s = ");
				 arr1[2]=sc.nextInt();
				 System.out.println("Enter the number of 4s =");
				 arr1[3]=sc.nextInt();
				 System.out.println("Enter the number of 6s = ");
				 arr1[4]=sc.nextInt();
				 
				 obj[j].total=total(arr1);
				 //calling total for run score of the player
				 
				 
				 
			 }
		 
		 
		 
		 for (int u=0;u<n;u++)
		 {
			  Q1 obj1= new Q1();
			 for(int r=u;r<n;r++)
			 {
				
				 if(obj[r].total>obj[u].total) {
					 obj1=obj[r];
					 obj[r]=obj[u];
					obj[u]=obj1;
					 
				 }
			 }
		 }
			 
			 
		 }
	 
	 //method for inserting.
	 static void insert() {
		 System.out.println("Enter the name of the player");
	     obj[5].name=sc.next();
	     int arr1[]= new int[5];
	     System.out.println("Enter the number of 1");
		 arr1[0]=sc.nextInt();
		 System.out.println("Enter the number of 2");
		 arr1[1]=sc.nextInt();
		 System.out.println("Enter the number of 3");
		 arr1[2]=sc.nextInt();
		 System.out.println("Enter the number of 4");
		 arr1[3]=sc.nextInt();
		 System.out.println("Enter the number of 6");
		 arr1[4]=sc.nextInt();
		 obj[5].total=total(arr1);
		 for (int u=0;u<6;u++) {
			  Q1 obj1= new Q1();
			 for(int r=u;r<6;r++) {
				
				 if(obj[r].total>obj[u].total) {
					 obj1=obj[r];
					 obj[r]=obj[u];
					obj[u]=obj1;
					 
				 }
			 }
		 }
		 
	 }
	 
	 //method for deleting
	 static void delete(int n) {
		 for( int y=n-1;y<5;y++) {
			 obj[y]=obj[y+1];
		 }
	 }
		 
		 
	 
	 public static void main(String args[]) {
		 
		 
		 System.out.println("\n\nEnter the  number of players u wanna enter details for = ");
		 int w=sc.nextInt();
		 input(w);
		 
		 //displaying total score i.e. run score of the players 
		 //whose record is just inserted.
		 
		 for(int y=0;y<w;y++) 
		 {
		 System.out.println(obj[y].name +" "+obj[y].total);
		 }
		 boolean flag =true;
		 while(flag) {
		 System.out.println("\n\nenter the function you wanna perform :  "
		 		+ " \n press 1 for insertion."
		 		+ "\n press 2 for printing top 5.,"
		 		+ "\n press 3 for deletion.,"
		 		+ "\n press 4 for exiting."
		 		);
		 int we=sc.nextInt();
		 //inputting choice of the user .
		 
		 if(we==1) 
		 {
			 //insertion
			 insert();
		 }
		 
		 
		 else if(we==2) 
		 {
			 //printing top5 players.
			 
			 for(int y=0;y<5;y++)
			 {
				 System.out.println();
				 System.out.println(obj[y].name +" has run score "+obj[y].total);
			  }
			 
		 }
		 
		 
		 else if(we==3) 
		 {
			 
			 //deletion 
			 System.out.println("\n\n Enter the number of player you wanna delete");
			 int re=sc.nextInt();
			 delete(re);
			 System.out.println("deletion of "+re+" is successful !");
			 
		 }
		 
		 
		 else if(we==4) {
			 //exiting 
			 flag=false;
		 }
		 
		 
		 }
		 
	 }

	

}

