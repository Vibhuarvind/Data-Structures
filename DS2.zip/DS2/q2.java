package lab2;
import java.util.*;
public class q2 {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter how many numbers you want to enter");
		int l=sc.nextInt();
		int Sum=0;
		int a[]=new int[l];
		System.out.println("enter the numbers");
		for(int i=0;i<l;i++) {
			a[i]=sc.nextInt();
			}
		for(int i=1;i<l;i++) {
			if(a[i]==0) {
				a[i-1]=0;
			}
			
			
		}
		for(int i=0;i<l;i++) {
			Sum=Sum+a[i];
		}
		System.out.println(Sum);
		sc.close();
	}
	
}
