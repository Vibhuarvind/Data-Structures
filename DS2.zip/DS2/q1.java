package lab2;
import java.util.*;

public class q1 {
	String name;
	int id;
	String depart;
	int salary;
	String address;
	int contact;
	String email;
	String pos;
	static Scanner sc = new Scanner(System.in);
	static q1 obj[] = new q1[50];
	static void input(int n)
	{
		for(int i=0;i<n; i++)
		{
			obj[i] = new q1();
		}
		for(int i=0;i<n; i++)
		{
			System.out.println("Enter the Name");
			obj[i].name = sc.next();
			System.out.println("Enter the id");
			obj[i].id = sc.nextInt();
			System.out.println("Enter the department");
			obj[i].depart = sc.next();
			System.out.println("Enter the salary");
			obj[i].salary = sc.nextInt();
			System.out.println("Enter the address");
			obj[i].address = sc.next();
			System.out.println("Enter the contact");
			obj[i].contact = sc.nextInt();
			System.out.println("Enter the Email");
			obj[i].email = sc.next();
			System.out.println("Enter the position");
			obj[i].pos = sc.next();
		}
	}
	static void del(int i, int n)
	{
		q1 ocb[] = new q1[n-1];
		for(int b=0; b<i;b++)
		{
			ocb[b] = obj[b];
		}
		for(int d=i+1;d<n-1; d++)
		{
			ocb[d] = obj[d];
		}
		for(int k=0; k<n-1;k++)
		{
			System.out.println(ocb[k].name + ", " + ocb[k].id + ", " + ocb[k].depart + ", " + ocb[k].address + ", " + ocb[k].contact + ", " + ocb[k].contact + ", " + ocb[k].pos) ;
		}
//		for(int a=i; a<n; a++)
//		{
//			obj[i] = obj[i+1];
//			n--;
//			
//		}
//		//obj[i] = null;
//		for(int j=0; j<i; j++)
//		{
//			data(i);
//		}
//		for(int o=i+1; o<n; o++)
//		{
//			data(o);
//		}
	}
	static void insert(int t, int n)
	{
		n++;
		for(int i=n-1; i>t; i--)
		{
			obj[i] = obj[i+1];
			
		}
		
		System.out.println("Enter the name");
		obj[t].name = sc.next();
		System.out.println("Enter the id");
		obj[t].id = sc.nextInt();
		System.out.println("Enter the department");
		obj[t].depart = sc.next();
		System.out.println("Enter the salary");
		obj[t].salary = sc.nextInt();
		System.out.println("Enter the address");
		obj[t].address = sc.next();
		System.out.println("Enter the contact");
		obj[t].contact = sc.nextInt();
		System.out.println("Enter the Email");
		obj[t].email = sc.next();
		System.out.println("Enter the position");
		obj[t].pos = sc.next();
	}
	static void data(int i)
	{
		System.out.println(obj[i].id + ", " + obj[i].name + ", " + obj[i].depart + ", " + obj[i].salary + ", " + obj[i].address + ", " + obj[i].contact + ", " + obj[i].email + ", " + obj[i].pos);
	}
	public static void main(String args[])
	{
		System.out.println("Enter the number of employees whose record you want to enter");
		int n = sc.nextInt();
		input(n);
		
		System.out.println("The total data is");
		for(int i=0; i<n;i++)
		{
			data(i);
		}
		System.out.println("Wanted to know the data of the specific person so enter the number");
		int per = sc.nextInt();
		data(per-1);
			
		
		
		System.out.println("delete any record, enter the employee number");
		int num = sc.nextInt();
		del(num-1,n);
			
		System.out.println("if Wanted to insert the data; enter the index where to be inserted");
		int nu = sc.nextInt();
		insert(nu, n);
		
		
		System.out.println("The overall updated databse is");
		for(int g=0; g<n;g++)
		{
			data(g);
			
		}
		
			
	}
}
