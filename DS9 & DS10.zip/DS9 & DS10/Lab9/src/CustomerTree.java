import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.io.IOException;
public class CustomerTree {
	int age;
	String name;
	CustomerTree left,right;
	CustomerTree(int age,String Name){
		this.age = age;
		this.name = Name;
	}
	public static void insert(CustomerTree t, CustomerTree newCustomer) {
		CustomerTree temp = t;
		if(temp.right==null) {
			temp.right = newCustomer;
		}
		else {
			temp = temp.right;
			while(temp!=null) {
				if(temp.name.compareTo(newCustomer.name)>=0) {
					if(temp.left==null) {
					temp.left = newCustomer;
					break;
					}
					else {
						temp = temp.left;
					}
				}
				else {
					if(temp.right==null) {
						temp.right = newCustomer;
						break;
					}
					else {
						temp = temp.right;
					}
				}
			}
		}
		
	}
	public static void display(CustomerTree t) {
		if(t == null) {
			return;
		}
		display(t.left);
		System.out.println(t.name + " " + t.age);
		display(t.right);
	}
	public static void main(String[] args) throws IOException {
		CustomerTree t = new CustomerTree(0,"A");
		while(true) {
			System.out.println("Enter 0 to exit or Any other integer to continue");
			Scanner sc = new Scanner(System.in);
			int op = sc.nextInt();
			if(op==0) {
				break;
			}
			else {
				System.out.println("Enter Command : ");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				String str = br.readLine();
				String[] tokens = str.split(" ");
				if(tokens[0].equals("I")){
					
					String name = tokens[1];
					int age = Integer.parseInt(tokens[2]);
					CustomerTree record = new CustomerTree(age,name);
					insert(t,record);
				}
				else if(tokens[0].equals("P")){
					display(t.right);
				}
			}
		}

	}

}
