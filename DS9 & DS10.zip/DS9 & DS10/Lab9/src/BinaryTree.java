import java.util.*;
class Node 
{ 
    int key; 
    Node left, right; 
  
    public Node(int item) 
    { 
        key = item; 
        left = right = null; 
    } 
} 
  
class BinaryTree 
{ 
    // Root of Binary Tree 
    Node root; 
  
    BinaryTree() 
    { 
        root = null; 
    } 
  
    static void insert(Node t,Node data) {
    	
    	Node temp = t;
    	while(true) {
    		if(temp.key<data.key) {
    			if(temp.right==null) {
    				temp.right = data;
    				break;
    			}
    			else {
    				temp = temp.right;
    			}
    		}
    		else {
    			if(temp.left==null) {
    				temp.left = data;
    				break;
    			}
    			else {
    				temp = temp.left;
    			}
    		}
    	}
    }
    int sum(Node node) {
    	int sum=0;
    	if(node==null) {
    		return 0;
    	}
    	sum+=sum(node.left);
    	sum+=node.key;
    	sum+=sum(node.right);
    	return sum;
    }
    void largest(Node node) {
    	Node temp = node;
    	while(temp.right!=null) {
    		temp = temp.right;
    	}
    	System.out.print(temp.key);
    }
    void printPostorder(Node node) 
    { 
        if (node == null) 
            return; 
  
        // first recur on left subtree 
        printPostorder(node.left); 
  
        // then recur on right subtree 
        printPostorder(node.right); 
  
        // now deal with the node 
        System.out.print(node.key + " "); 
    } 
  
    /* Given a binary tree, print its nodes in inorder*/
    void printInorder(Node node) 
    { 
        if (node == null) 
            return; 
  
        /* first recur on left child */
        printInorder(node.left); 
  
        /* then print the data of node */
        System.out.print(node.key + " "); 
  
        /* now recur on right child */
        printInorder(node.right); 
    } 
  
    /* Given a binary tree, print its nodes in preorder*/
    void printPreorder(Node node) 
    { 
        if (node == null) 
            return; 
  
        /* first print data of node */
        System.out.print(node.key + " "); 
  
        /* then recur on left sutree */
        printPreorder(node.left); 
  
        /* now recur on right subtree */
        printPreorder(node.right); 
    } 
    void largest(BinaryTree tree) {
    	
    }
    // Wrappers over above recursive functions 
    void printPostorder()  {     printPostorder(root);  } 
    void printInorder()    {     printInorder(root);   } 
    void printPreorder()   {     printPreorder(root);  } 
  
    // Driver method 
    public static void main(String[] args) 
    { 
        BinaryTree tree = new BinaryTree(); 
        while(true) {
        	System.out.println("Enter 0 to break : ");
        	Scanner sc = new Scanner(System.in);
        	int choice = sc.nextInt();
        	if(choice==0) {
        		break;
        	}
        	else {
        		System.out.println("Enter Element : ");
        		int elem = sc.nextInt();
        		Node node = new Node(elem);
        		if(tree.root==null) {
        			tree.root = node;
        		}
        		else {
        		insert(tree.root,node);
        		}
        		}
        }
  
        System.out.println("Preorder traversal of binary tree is "); 
        tree.printPreorder(); 
  
        System.out.println("\nInorder traversal of binary tree is "); 
        tree.printInorder(); 
  
        System.out.println("\nPostorder traversal of binary tree is "); 
        tree.printPostorder(); 
        
        System.out.println("\nLargest Element : ");
        tree.largest(tree.root);
        
        System.out.println("\nSum of elements : ");
        System.out.print(tree.sum(tree.root));
    } 
}