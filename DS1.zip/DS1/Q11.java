package datastructure;

public class Q11 {
	int arry[],x;
	public void check(int a[]) {
		arry=a;
		for(int i=0; i<arry.length;i++) {
			if(arry[i]==0 || arry[i]==-1) {
				System.out.println("Arrays contains zero or -ve one !");
				
			}
		}
}}
