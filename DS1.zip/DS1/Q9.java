package datastructure;

public class Q9 {

	int ar[],min,max,y,ar1[];
	public void Min(int x[]) {
		ar=x;
		min=ar[0];
		for(int i=0;i<ar.length;i++) {
			 if(min>ar[i])  
				  min=ar[i];  
			
		}
		System.out.println("MINIMUM ELEMENT= "+min);
		
	}
	public void Max(int x[]) {
		ar1=x;
		max=ar1[0];
		for(int j=0;j<ar1.length;j++) {
			 if(max<ar1[j])  
				  max=ar1[j];  
			
		}
		System.out.println("MAXIMUM ELEMENT= "+max);
}}
