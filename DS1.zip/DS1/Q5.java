package datastructure;
import java.util.Scanner;
public class Q5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of array = ");
		int n= sc.nextInt();
		System.out.println("now enter "+n+ " elements = ");
		int []arr=new int[n];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("enter the element you want = ");
		int x=sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==x)
			{
				System.out.println("element found at position "+i);
				break;
		    }
			System.out.println("element not found ");
		}
			
	}

}
