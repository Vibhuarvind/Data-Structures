package datastructure;
import java.util.Arrays;
import java.util.Scanner;
public class Q8 {
    public static void main(String[] args) 
    {
        int n, location, x;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of array =");
        n = sc.nextInt();
        int a[] = new int[n+1];
        System.out.println("Enter the elements = ");
        for(int i = 0; i < n; i++)
        {
            a[i] = sc.nextInt();
        }
        System.out.print("now pls enter location u wanna insert element= ");
        location = sc.nextInt();
        System.out.print("enter element u wanna insert = ");
        x = sc.nextInt();
        for(int i = (n-1); i >= (location-1); i--)
        {
            a[i+1] = a[i];
        }
        a[location-1] = x;
        System.out.print("After inserting:");
        for(int i = 0; i < n; i++)
        {
            System.out.print(a[i]+",");
        }
        System.out.print(a[n]);
    }
}
