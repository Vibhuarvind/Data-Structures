package datastructure;

public class Q6M {
		int ar[],sum=0,y;
		public void Index (int x[],int n) {
			ar=x;
			y=n;
			//System.out.println("index of the element n is");
			for(int i=0;i<ar.length;i++) {
				if(ar[i]==n) {
					System.out.println("Index of the element "+ n +" is = "+i);
				}
			}
		}
	}
