package datastructure;
import java.util.Scanner;
public class q9ii {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter range of Fibonacci series");
		int N= sc.nextInt();
		int N1=0,N2=1,sum;
		while(N>0) {
			System.out.print(N1+" ");
			sum=N1+N2;
			N1=N2;
			N2=sum;
			N--;
		}

	}

}
