package datastructure;

public class Q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,l ,j,k,m,n,x,y;
		for(i=1;i<=7;i++) {
			for(j=7-i;j>=1;j--) {
				System.out.print("  ");
			}
			for(k=i;k>=1;k--) {
				System.out.print("*");
				
			}
			for(l=2;l<=i;l++) {
				System.out.print("*");	
			}
			System.out.println();
		}
	
		for(m=6;m>=1;m--) {
			for(n=m-1;n<6;n++) {
				System.out.print("  ");
			}
			for(x=m;x>=1;x--) {
				System.out.print("*");
			}
			for(y=2;y<=m;y++) {
				System.out.print("*");
			}
			System.out.println();
			
		}
	}

}
