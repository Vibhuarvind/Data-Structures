package datastructure;

public class Q10 {
	int ar[],sum=0,y;
	public void Duplicate(int x[]) {
		ar=x;
		for(int i=0;i<ar.length;i++) {
			for(int j=i+1;j<ar.length;j++) {
				if(ar[i]==ar[j]) {
					System.out.println("Duplicate element is  "+ar[i]);
				}
			}
		}
   }
}
