package datastructure;
import java.util.Scanner;
public class Q7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int flag=1,location=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size of array = ");
		int n=sc.nextInt();
		
		int a[]=new int[n];
		System.out.println("now enter the all elemnets = ");
		for(int i=0;i<a.length;i++){
			a[i]=sc.nextInt();
		}
		
		System.out.println("now enter the element you wanna delete = ");
		int x=sc.nextInt();
		for(int i=0;i<n;i++){
			if(a[i]==x){
				flag=1;
				location=i;
				break;
			}
			else{
				flag=0;
			}
		}
		if(flag==1){
			for(int i=location+1;i<n;i++){
					a[i-1]=a[i];
			}
			System.out.println("after deletion of "+x);
			for(int i=0;i<n-2;i++){
				System.out.println(a[i]+" ");
			}
			System.out.println(a[n-2]);
		}
		else
			System.out.println("element not found !");
			
	}

}
