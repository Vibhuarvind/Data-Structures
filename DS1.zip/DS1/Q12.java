package datastructure;
import java.util.Scanner;
public class Q12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int n,  a=1, b, c, i=1, count = 0;
			double sum = 0;
			 
		        System.out.println("First ten Armstrong numbers:");
		        while(i<=10)
		        {
		            
		            n=a;
		            while(n>0) {
		            	c=n%10;
		            	count++;
		            	n=n/10;
		            }
		            //System.out.println(n +" "+count);
		            n=a;
		            while(n > 0)
		            {
		                b = n % 10;
		                sum = sum + Math.pow(b, count);
		                n = n / 10;
		            }
		            if(sum == a)
		            {
		                System.out.println(a+" ");
		                i++;
		            }
		            sum = 0;
		            a++;
		            count=0;
		           
		        }
	}
}
