package datastructure;
import java.util.Scanner;
public class Q9i {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no. to find factorial");
		int number=sc.nextInt();
		do
		{
			int i=1,fact=1;
			while(i<=number){
				fact=fact*i;
				i++;
			}
			System.out.println("Factorial of given "+number+" is "+fact);
			number+=1;
		}
		while(number<1);
	}
}
