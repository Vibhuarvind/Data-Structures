package datastructure;
import java.util.Scanner;
public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n= sc.nextInt();
		for (int x=1;x<=n;x++) 
		{
			for(int y=n;y>=x;y--)
			{
				System.out.print(" ");
			}
			for (int z=1;z<=x;z++)
			{
				System.out.print(x);
				System.out.print(" ");
			}
			System.out.println();
		}
	}
}
