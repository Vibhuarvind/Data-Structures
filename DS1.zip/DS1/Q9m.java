package datastructure;
import java.util.Scanner;
public class Q9m {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Q9 obj= new Q9();
		System.out.println("enter size = ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		int n1,i;
		for(i=0;i<n;i++) {
			System.out.println("enter values = ");
			n1=sc.nextInt();
			arr[i]=n1;
		}
		//int y[] =    {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
		obj.Min(arr);
		obj.Max(arr);
	}
}
