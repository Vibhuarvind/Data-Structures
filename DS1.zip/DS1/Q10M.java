package datastructure;
import java.util.Scanner;
public class Q10M {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Q10 obj= new Q10();
		System.out.println("enter SIZE!! = ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		int n1,i;
		for(i=0;i<n;i++) {
			System.out.println("enter values = ");
			n1=sc.nextInt();
			arr[i]=n1;
		}
		//int y[] =    {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
		obj.Duplicate(arr);
	}

}
