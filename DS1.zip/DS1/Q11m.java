package datastructure;
import java.util.Scanner;
public class Q11m {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Q11 obj= new Q11();
		System.out.println("enter size = ");
		int n=sc.nextInt();
		int arry[]=new int[n];
		int n1,i;
		for(i=0;i<n;i++) {
			System.out.println("enter values = ");
			n1=sc.nextInt();
			arry[i]=n1;
		}
		//int y[] =    {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
		obj.check(arry);
	}
}
