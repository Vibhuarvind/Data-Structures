package dslab11;
import java.util.concurrent.atomic.AtomicInteger;
//Data structure to store a Binary Tree node
class Nodeee
{
	int data;
	Nodeee left = null, right = null;

	Nodeee(int data) {
		this.data = data;
	}
}

class Q3
{
	// Helper function to find maximum difference between a node and its
	// descendants in a binary tree
	public static int maxDifference(Nodeee root, AtomicInteger diff)
	{
		// base case: if tree is empty, return infinity
		if (root == null) {
			return Integer.MAX_VALUE;
		}

		// recur for left and right subtree
		int left = maxDifference(root.left, diff);
		int right = maxDifference(root.right, diff);

		// find maximum difference between current node and its descendants
		int d = root.data - Math.min(left, right);

		// update the maximum difference found so far if required
		diff.set(Math.max(diff.get(), d));

		// in order for difference to be maximum, the function should return
		// minimum value among all nodes in sub-tree rooted at it
		return Math.min(Math.min(left, right), root.data);
	}

	// Find maximum difference between a node and its descendants in a binary tree
	public static int maxDifference(Nodeee root)
	{
		// Using AtomicBoolean as Integer is passed by value in Java
		AtomicInteger diff = new AtomicInteger(Integer.MIN_VALUE);
		maxDifference(root, diff);

		return diff.get();
	}

	// main function
	public static void main(String[] args)
	{
		Nodeee root = new Nodeee(6);
		root.left = new Nodeee(3);
		root.right = new Nodeee(8);
		root.right.left = new Nodeee(2);
		root.right.right = new Nodeee(4);
		root.right.left.left = new Nodeee(1);
		root.right.left.right = new Nodeee(7);

		System.out.print(maxDifference(root));
	}
}
