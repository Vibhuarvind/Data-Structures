package dslab11;
class Nodee
{ 
	int data; 
	Nodee left, right; 

	Nodee(int item) { 
		data = item; 
		left = right = null; 
	} 
} 

class Q2
{ 
	Nodee root; 

	/* This function counts the number of nodes in a binary tree */
	int countNodes(Nodee root) 
	{ 
		if (root == null) 
			return (0); 
		return (1 + countNodes(root.left) + countNodes(root.right)); 
	} 

	/* This function checks if the binary tree is complete or not */
	boolean isComplete(Nodee root, int index, int number_nodes) 
	{ 
		// An empty tree is complete 
		if (root == null)		 
		return true; 

		// If index assigned to current node is more than 
		// number of nodes in tree, then tree is not complete 
		if (index >= number_nodes) 
		return false; 

		// Recur for left and right subtrees 
		return (isComplete(root.left, 2 * index + 1, number_nodes) 
			&& isComplete(root.right, 2 * index + 2, number_nodes)); 

	} 

	// Driver program 
	public static void main(String args[]) 
	{ 
		Q2 tree = new Q2(); 
		Node NewRoot = null; 
		tree.root = new Nodee(1); 
		tree.root.left = new Nodee(2); 
		tree.root.right = new Nodee(3); 
		tree.root.left.right = new Nodee(5); 
		tree.root.left.left = new Nodee(4); 
		tree.root.right.right = new Nodee(6); 
		
		int node_count = tree.countNodes(tree.root); 
		int index = 0; 
		
		if (tree.isComplete(tree.root, index, node_count)) 
			System.out.print("The binary tree is complete"); 
		else
			System.out.print("The binary tree is not complete"); 
	} 
} 


