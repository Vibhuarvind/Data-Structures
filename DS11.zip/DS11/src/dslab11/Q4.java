package dslab11;
class NodeX
{ 
	int data; 
	NodeX left, right; 

	NodeX(int item) 
	{ 
		data = item; 
		left = right = null; 
	} 
} 

class Q4 
{ 
	NodeX root; 

	void printPaths(NodeX node) 
	{ 
		int path[] = new int[1000]; 
		printPathsRecur(node, path, 0); 
	} 

	void printPathsRecur(NodeX node, int path[], int pathLen) 
	{ 
		if (node == null) 
			return; 

		path[pathLen] = node.data; 
		pathLen++; 

		if (node.left == null && node.right == null) 
			printArray(path, pathLen); 
		else
		{ 
			
			printPathsRecur(node.left, path, pathLen); 
			printPathsRecur(node.right, path, pathLen); 
		} 
	} 


	void printArray(int ints[], int len) 
	{ 
		int i; 
		for (i = 0; i < len; i++) 
		{ 
			System.out.print(ints[i] + " "); 
		} 
		System.out.println(" "); 
	} 

	// driver program to test above functions 
	public static void main(String args[]) 
	{ 
		Q4 tree = new Q4(); 
		tree.root = new NodeX(10); 
		tree.root.left = new NodeX(8); 
		tree.root.right = new NodeX(2); 
		tree.root.left.left = new NodeX(3); 
		tree.root.left.right = new NodeX(5); 
		tree.root.right.left = new NodeX(2); 
		tree.printPaths(tree.root); 
	} 
} 


