package DS5;
import java.util.Scanner;
public class Q2 {
	
	Node head;
	int ele,count=0;
	static class Node
	{
		int data;
		Node link;
		Node(int d)
		{
			data=d;
			link=null;
		}
	}
	public void Element(int x) 
	{
		ele=x;
		Node ptr=head;
		while(ptr!=null)
		{
			count++;
			ptr=ptr.link;
	   }
		int pos=count-(ele-1);
		System.out.println("Position from first = "+pos);
		ptr=head;
		count=1;
		Node ptr1=null;
		while(count!=pos) 
		{
			ptr1=ptr;
			count++;
			ptr=ptr.link;
		}
		System.out.println(ptr.data);
	}
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		Node ptr1;
		Q2 obj = new Q2();
		obj.head=new Node(1);
		ptr1=obj.head;
        for(int j=2;j<=4;j++)
        {
			Node z=new Node(j);
			ptr1.link=z;
			ptr1=z;
	    }
        
        System.out.println("enter the node to be displayed frm the last");
        int x= sc.nextInt();
        obj.Element(x);
        
	}
}

