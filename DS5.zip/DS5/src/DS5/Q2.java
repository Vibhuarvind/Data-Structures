package DS5;
import java.util.Scanner;
public class Q2 {
    node head;

    static class node {
        node next;
        int data;

        node() {
            next = null;
        }
    }

    public static Q2 push(Q2 link, int data) {
        node new_node = new node();
        new_node.data = data;
        if (link.head == null) {
            link.head = new_node;
        } else {
            node point = link.head;
            while (point.next != null) {
                point = point.next;
            }
            point.next = new_node;
        }
        return link;
    }

    public static void print(Q2 link) {
        node point = link.head;
        while (point != null) {
            System.out.print(point.data + " ");
            point = point.next;
        }
    }
    public static Q2 reverse(Q2 link)
    {
    	//reversing the link
    	
        node current = link.head;
        node prev = null;
        node forward = null; 
        while(current !=null)
        {
            forward = current.next;
            current.next = prev;
            //System.out.println(current.next.data);
            prev = current;
            current = forward;
            //System.out.println(current.data);
        }
        link.head = prev;

        return link;
    }
    public static void print_nth(Q2 link,int node_no)
    {
        reverse(link);
        node point = link.head;
        int no = 1;
        while (no != node_no)
        {
            point = point.next;
            no ++;
        }
        System.out.println(point.data);

    }

    public static void main(String[] args) {
        Q2 a = new Q2();
        a = push(a,1);
        a = push(a,2);
        a = push(a,3);
        a = push(a,4);
        System.out.println("Original list = ");
        print(a);
        System.out.println();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the nth node you want to print from the end :");
        int number = sc.nextInt();
        print_nth(a,number);
    }
}