package DS5;
public class Q7MAIN {

	public static void main(String[] args) 
	{ 
		Q7 list = new Q7();
		list.push(7); 
		list.push(6); 
		list.push(5); 
		list.push(4); 
		list.push(3); 
		list.push(2); 
		list.push(1); 

		System.out.print("\n Linked list before "); 
		list.printList(); 

		//swapping 1 and 6
		list.swapNodes(1, 6); 

		System.out.print("\n Linked list after swapping "); 
		list.printList(); 
	} 
}
