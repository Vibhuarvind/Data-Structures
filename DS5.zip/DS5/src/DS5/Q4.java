package DS5;
//creating node
public class Q4 {
    node head;

    static class node {
        node next;
        int data;

        node() {
            next = null;
        }
    }

    public static Q4 push(Q4 link, int data) {
        node new_node = new node();
        new_node.data = data;
        if (link.head == null) {
            link.head = new_node;
        } else {
            node point = link.head;
            while (point.next != null) {
                point = point.next;
            }
            point.next = new_node;
        }
        return link;
    }

    public static void print(Q4 link) {
        node point = link.head;
        while (point != null) {
            System.out.print(point.data + " ");
            point = point.next;
        }
    }
    public static void join(Q4 a, Q4 b)
    {
        node prev = null;
        node current = a.head;
        while (current !=null)
        {
            prev = current;
            current = current.next;
        }
        prev.next = b.head;
//        print(a);
    }

    public static void main(String[] args) {
        Q4 a = new Q4();
        Q4 b = new Q4();
        a = push(a,5);
        a = push(a,7);
        a = push(a,9);
        b = push(b,4);
        b = push(b,6);
        b = push(b,8);
        System.out.println("here's ur linked list 1 = ");
        print(a);
        System.out.println();
        System.out.println("here's ur linked list 2 = ");
        print(b);
        
        join(a,b);
        System.out.println();
        System.out.println("After joining link 2 in link 1 = ");
        print(a);

    }
}