package DS5;
class Q7
{ 
	Node head; 
	
	static class Node 
	{ 
		int data; 
		Node next; 
		Node(int d) 
		{ 
			data = d; 
			next = null; 
		} 
	}
	
	public void swapNodes(int x, int y) 
	{ 
		
		if (x == y) 
			//wont't do anything
			return; 
		Node prevX = null, currX = head; 
		while (currX != null && currX.data != x) 
		{ 
			prevX = currX; 
			currX = currX.next; 
		} 
		
		Node prevY = null, currY = head; 
		while (currY != null && currY.data != y) 
		{ 
			prevY = currY; 
			currY = currY.next; 
		} 

		//if both nodes are not there in linked list it does nothing.
		if (currX == null || currY == null) 
			return; 

		//if prevX is not head in linked list
		if (prevX != null) 
			prevX.next = currY; 
		else
			head = currY; 
		
		//if pervY is not head in the linked list
		if (prevY != null) 
			prevY.next = currX; 
		else 
			head = currX; 

		//SWAPPING
		Node temp = currX.next; 
		currX.next = currY.next; 
		currY.next = temp; 
	} 

	public void push(int new_data) 
	{ 
		Node new_Node = new Node(new_data); 

		new_Node.next = head; 

		head = new_Node; 
	} 

	public void printList() 
	{ 
		Node tNode = head; 
		while (tNode != null) 
		{ 
			System.out.print(tNode.data+" "); 
			tNode = tNode.next; 
		} 
	} 
} 

