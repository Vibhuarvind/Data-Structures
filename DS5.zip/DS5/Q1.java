package DS5;

public class Q1 {
	Node head;
	Node ptr;
	Node ptr2;
	int X,a,count=0;
	
	
	static class Node{
		int id;
		
		Node link;
		Node(int d){
			id=d;
			
			link=null;
			
		}
		
	}
	
	public void Traverse() {
		ptr=head;
		while(ptr!=null) {
			System.out.print(ptr.id+" " );
			count++;
			ptr=ptr.link;
		}
		System.out.println("\nTotal number of elements = "+count);
		System.out.println(" now here's the output! ");
		int a=count%2;
		if (a!=0) {
			Node ptr2=head;
			while((ptr2.link!=null) ) {
				
				System.out.println(" "+ptr2.id+" ");
				ptr2=ptr2.link.link;
			}
			System.out.println(" "+ptr2.id+" ");
		}
		else {
			Node ptr3=head;
			while(ptr3!=null) {
				System.out.println(" "+ptr3.id+" ");
				ptr3=ptr3.link.link;
			}
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node ptr1;
		Q1 obj = new Q1();
		obj.head=new Node(1);
		ptr1=obj.head;
        for(int j=2;j<=8;j++) {
			
			
			Node z=new Node(j);
			ptr1.link=z;
			ptr1=z;
			
		}
        obj.Traverse();

	}

}

