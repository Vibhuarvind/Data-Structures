package DS5;

public class Q4
{
	Node1 head1;
	Node2 head2;
	int count=0;	
	static class Node1
	{
		int data;
		Node1 link1;
		
		Node1(int d)
		{
			data=d;
			link1=null;
			
		}
    }
	
	static class Node2
	{
		int data;
		Node2 link;
		Node2(int d)
		{
			data=d;
			link=null;	
		}
	}
	
	public void join() 
	{
		Node1 ptr1=head1;
		Node2 ptr2=head2;
		while(ptr1.link1!=null) 
		{
			ptr1=ptr1.link1;
		}
		System.out.println(ptr1.data);
		//ptr1.link1=ptr2;
		head2=null;
		Node1 ptr=head1;
		
		while(ptr!=null)
		{
			System.out.println(ptr.data);
			ptr=ptr.link1;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node1 ptr1;
		Q4 obj = new Q4();
	    obj.head1=new Node1(1);
		ptr1=obj.head1;
        for(int j=2;j<=6;j++) 
        {
			Node1 z=new Node1(j);
			ptr1.link1=z;
			ptr1=z;	
		}
        Node2 ptr2;
        obj.head2=new Node2(7);
        ptr2=obj.head2;
        for(int j=8;j<=12;j++) 
        {
			Node2 z=new Node2(j);
			ptr2.link=z;
			ptr2=z;
			j++;
        } 
        obj.join();
	}
}

